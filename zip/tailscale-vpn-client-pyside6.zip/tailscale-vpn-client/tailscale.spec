# tailscale.spec
# PyInstaller spec file for TAILSCALE VPN Client (PySide6 edition)
#
# Build command:
#   pyinstaller tailscale.spec
#
# The .ui files are bundled as data so QUiLoader can find them at runtime
# inside the frozen EXE via resource_path().

import sys
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

# ---------------------------------------------------------------------------
# Data files — .ui files + assets
# ---------------------------------------------------------------------------
datas = [
    # UI files (relative source path, destination folder inside EXE)
    ("pygui/windows/main_window.ui",          "pygui/windows"),
    ("pygui/windows/tab_widget.ui",           "pygui/windows"),
    ("pygui/dialogs/settings.ui",             "pygui/dialogs"),
    ("pygui/dialogs/about.ui",                "pygui/dialogs"),
    ("pygui/dialogs/credentials.ui",          "pygui/dialogs"),
    ("pygui/dialogs/progress.ui",             "pygui/dialogs"),
    ("pygui/dialogs/traffic.ui",              "pygui/dialogs"),
    ("pygui/dialogs/log_viewer.ui",           "pygui/dialogs"),
    ("pygui/dialogs/license.ui",              "pygui/dialogs"),
    ("pygui/dialogs/readme.ui",               "pygui/dialogs"),
    # App icon + any other assets
    ("assets",                                "assets"),
    # PySide6 QtWebEngine resources (required for QWebEngineView)
    *collect_data_files("PySide6", includes=["**/*.pak", "**/*.dat",
                                              "**/QtWebEngineProcess*"]),
]

# ---------------------------------------------------------------------------
# Hidden imports that PyInstaller may miss
# ---------------------------------------------------------------------------
hiddenimports = [
    "PySide6.QtUiTools",
    "PySide6.QtWebEngineWidgets",
    "PySide6.QtWebEngineCore",
    "PySide6.QtNetwork",
    "cryptography",
    "keyring",
    "psutil",
    "markdown",
    *collect_submodules("logic"),
    *collect_submodules("pylogic"),
    *collect_submodules("os_specific"),
]

# ---------------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------------
block_cipher = None

a = Analysis(
    ["main.py"],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "tkinter",
        "customtkinter",
        "matplotlib",
        "numpy",
        "PIL",
        "pywebview",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

# ---------------------------------------------------------------------------
# EXE
# ---------------------------------------------------------------------------
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="TailscaleVPNClient",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,                    # No console window on Windows
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon="assets/icon.ico"            # Windows .ico — replace with your icon path
    if sys.platform == "win32" else None,
)

# ---------------------------------------------------------------------------
# COLLECT — one-folder distribution (easier to deploy than one-file)
# ---------------------------------------------------------------------------
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="TailscaleVPNClient",
)
